package com.codingdojo.jspproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspprojectApplication.class, args);
	}
}
